#pragma once

#define HTTP_SERVER "103.82.20.232"
#define HTTP_PORT 80

#define TFTP_SERVER "103.82.20.232"
